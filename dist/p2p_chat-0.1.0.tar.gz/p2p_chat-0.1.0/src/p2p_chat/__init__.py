"""
P2P Chat - A simple asynchronous chat application with offline message support
"""

__version__ = "0.1.0"