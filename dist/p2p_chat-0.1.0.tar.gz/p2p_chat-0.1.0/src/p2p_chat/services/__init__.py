"""
Services module for P2P Chat
"""